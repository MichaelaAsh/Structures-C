## a2.q1.c : 
assigns random numbers from 1 to 63 to 6x9 array that stored in a structure
Then it swaps two rows and two columns that are also random.

## a2.q2.c  : 
assigns random numbers from 1 to 10 to 6x9 array that stored in a structure

The functions for the mains is in a header file called functions.h


In q2 (b) the numbers assigned to a1, a2 and a_shallow appears in each of these arrays.
Therefore, in these 3 arrays, what is done to one appears in the others
In a_deep the number assigned stays only in that array, it doesn't affect the others.

a2.q2 (c) a1, a2, and a_shallow value in the array changed to the same values as b1.
a_deep did not change from how it was in q2 (b). After assigning the values,
 a1, a2, a_shallow, b1 values appear in all these areas.
Therefore, in these 4 arrays, what is done to one appears in the others.
