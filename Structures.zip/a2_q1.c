#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#define FAIL 1
#define SUCCESS 2

int main (int argc, char *argv[]) {

   if ( argc != 1) {
      printf("Usage: ./a2_q1 \n"); /* remember to change name */
      exit(FAIL);
  }

    double first_num = 1.0;
    double second_num = 63.0;

    header_1();

    if ( argc != 1) {
      printf("Usage: ./a2_q2 first_num second_num\n"); /* remember to change name */
      exit(FAIL);
    }

    struct Double_Array *a1 = double_array(6,9);/* allocated size to array in struct 6 by 9 array */
    randomize_array( a1, first_num, second_num);/* assigns random numbers to the elements of the array */
    print_array(a1);

/*==============================================================================*/
                                 /*swap rows */
    int row_1 = random(0,5);
    int row_2 = random(0,5);

    if (row_1 == row_2) {/* checks to see if the same random number if picked for both */
      row_2 = random(0,5);
    }
    swap_rows(a1, row_1, row_2);

    printf ("the rows that are going to swapped are %d and %d\n", row_1+1, row_2+1);
    print_array(a1);
/*==============================================================================*/
                                /*Swap columns*/
    int col_1 = random(0,8);
    int col_2 = random(0,8);

    if (col_1 == col_2) {/* checks to see if the same random number if picked for both */
        col_2 = random(0,5);
    }
    swap_columns(a1, col_1, col_2);

    printf ("the columns that are going to swapped are %d and %d\n", col_1+1, col_2+1);
    print_array(a1);

    putchar ('\n');
    free_structure (a1);

    return (SUCCESS);
}
