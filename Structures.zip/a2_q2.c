#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#define FAIL 1
#define SUCCESS 2

int main ( int argc, char *argv[]) {

   double first_num = 1.0;
   double second_num = 10.0;

   if ( argc != 1) {
     printf("Usage: ./a2_q2 \n"); /* remember to change name */
     exit(FAIL);
   }

    header_2(); /* prints out question_2a header */
    char *header_1 = "The structure pointed to by a1 is ";
    char *header_2 = "The structure pointed to by a2 is: ";
    char *header_3 = "The structure pointed to by a_shallow is ";
    char *header_4 = "The structure pointed to by a_deep is ";
    char *header_5 = "The structure pointed to by b1 is ";

    struct Double_Array *a1 = double_array(6,9); /* allocated size to array in struct 6 by 9 array */
    randomize_array( a1, first_num, second_num); /* assigns random numbers to the elements of the array */
    print_struct (a1, header_1);


    struct Double_Array *a2 = a1;
    print_struct(a2, header_2);

    struct Double_Array *a_shallow = shallow_copy(a1);
    print_struct(a_shallow, header_3);

    struct Double_Array *a_deep = deep_copy(a1);
    print_struct(a_deep, header_4);

    putchar('\n');
/*==============================================================================*/
                             /*Question 2b*/
    header3(); /* prints question_2b header */
    question_2b (a1, header_1,  a2,header_2, a_shallow, header_3, a_deep, header_4);/* sets the elements in the array to number and print the arrays*/
/*==============================================================================*/
                            /*Question 2c */
  header4(); /* prints question_2c header */

  struct Double_Array *b1 = double_array(6,9);
  first_num = 10;
  second_num = 20;
  randomize_array( b1, first_num, second_num);
  a2 -> array = b1 -> array;

  print_all_array (a1, header_1, a2,header_2, a_shallow, header_3, a_deep, header_4);
  question_2c(a1, header_1 , a2,header_2, a_shallow, header_3, a_deep, header_4, b1, header_5); /* sets the elements in the array to number and print the arrays*/


  /*free_structure(b1);*/ 
  free_structure(a_deep);
  free_structure (a1);




  return (SUCCESS);
}/* end of code */
