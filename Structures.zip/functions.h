#include <stdio.h>
#include <stdlib.h>
/*==============================================================================*/
#define MAX_COL 9
void header_1 ( ) {

   int i;

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

   int j = 0;
   int half_way = MAX_COL*9/2;
   while (j < half_way) {
     putchar(' ');
     j++;
   }
   printf("Quesion 1");
   putchar('\n');

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

}
/*==============================================================================*/
#define MAX_COL 9
void header4 ( ) {

   int i;

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

   int j = 0;
   int half_way = MAX_COL*9/2;
   while (j < half_way) {
     putchar(' ');
     j++;
   }
   printf("Quesion 2c");
   putchar('\n');

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

}
/*==============================================================================*/
#define MAX_COL 9
void header_2 ( ) {

   int i;

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

   int j = 0;
   int half_way = MAX_COL*9/2;
   while (j < half_way) {
     putchar(' ');
     j++;
   }
   printf("Quesion 2a");
   putchar('\n');

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

}
/*==============================================================================*/
#define MAX_COL 9
void header3 ( ) {

   int i;

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

   int j = 0;
   int half_way = MAX_COL*9/2;
   while (j < half_way) {
     putchar(' ');
     j++;
   }
   printf("Quesion 2b");
   putchar('\n');

   for  (i = 0; i < MAX_COL*9; i++) {
     putchar('-');
   }
   putchar('\n');

}
/*==============================================================================*/
struct Double_Array {

  int row_size;
  int col_size;
  double **array;

};
/*==============================================================================*/
struct Double_Array *double_array (int  row_size, int col_size) {

  struct Double_Array *data = malloc (sizeof(struct Double_Array));

  data -> array = malloc (sizeof(double *) * row_size );
  data -> row_size = 6;
  data -> col_size = 9;

  int i;
  for (i = 0; i < row_size; i++) {
    data ->array[i] =  malloc (sizeof(double *) * col_size );
  }

  return data;
}
/*==============================================================================*/
double random (double first_num, double second_num) {
  double random_num;

  if ( first_num > second_num ) {
   /* assuming b > a  for the formula to work*/
  random_num = ((double) rand() / (double) RAND_MAX) * ((first_num - second_num) + second_num);
  } else {

    double original_2 = second_num;
     second_num =  first_num;
      first_num = original_2;
    random_num = ((double) rand() / (double) RAND_MAX) * ((first_num - second_num ) + second_num);
  }

 return (random_num);
}
/*==============================================================================*/

#define MAX_ROWS 6
#define MAX_COL 9
void randomize_array (struct Double_Array *data, double first_num, double second_num) {
/* functions generates random numbers between first_num and second_num (inclusive) and puts
them in the 2d array located in struct Double_Array */
    int row;
    int col;

    for ( row = 0; row  < MAX_ROWS; row++) {
          for (col = 0; col < MAX_COL; col++){
               data -> array[row][col] = random(first_num, second_num);
               /* puts random numbers in array */
          }/* column loop */

    }/* rows loop */
}
/*==============================================================================*/

#define MAX_ROWS 6
#define MAX_COL 9
void print_array (struct Double_Array *data) {

  int row;
  int col;

  for ( row = 0; row  < MAX_ROWS; row++) {
        for (col = 0; col < MAX_COL; col++){
               printf("%6.1f   ", data -> array[row][col]);

        }
          putchar('\n');
  }

  putchar('\n');
  putchar('\n');

}

/*==============================================================================*/

void free_structure (struct Double_Array *data){

  int i;

  for (i = 0; i < data ->row_size; i++) {
      free(data -> array[i]);
  }

  free (data -> array);
  free(data);

}
/*==============================================================================*/
int swap_rows (struct Double_Array *data, int row_1, int row_2) {

  int col = 0;
  double switch_row_1[6][9];

  for ( col = 0; col < data -> col_size; col++) {
     switch_row_1[row_1][col] = data -> array[row_1][col];
     data -> array[row_1][col] = data -> array[row_2][col];
     data -> array[row_2][col] =  switch_row_1[row_1][col];
  }


  return (1);

}

/*==============================================================================*/
int swap_columns (struct Double_Array *data, int col_1, int col_2) {

  int row = 0;
  double switch_col_1[6][9];


  for ( row = 0; row < data -> row_size; row++) {
     switch_col_1[row][col_1] = data -> array[row][col_1];
     data -> array[row][col_1] = data -> array[row][col_2];
     data -> array[row][col_2] =  switch_col_1[row][col_1];
  }
  return (1);

}

/*==============================================================================*/
struct Double_Array *shallow_copy( struct Double_Array *data) {

   return (data);
}


/*==============================================================================*/
struct Double_Array *deep_copy (struct Double_Array *data ) {

  int i;
  int j;

  struct Double_Array *data_2 = double_array (6, 9);

  for (i = 0; i < data -> row_size; i++) {
    for (j = 0; j < data -> col_size; j++) {
        data_2 -> array[i][j] = data -> array[i][j];
    }
  }

   return (data_2);
}

/*==============================================================================*/

void print_struct ( struct Double_Array *data, char *header) {

  printf ("%s: \n", header);
  printf ("struct address = %p \n", data);
  printf("row_size = %d, col_size = %d \n", data -> row_size,  data -> col_size);
  printf ("array address = %p \n", data -> array);
  putchar('\n');
  print_array(data);


}

/*==============================================================================*/
void question_2b (struct Double_Array *a1, char *header_1, struct Double_Array *a2, char *header_2,  struct Double_Array *a_shallow, char *header_3 , struct Double_Array *a_deep ,char *header_4 ){

  a1 -> array[0][1] = 100.0;
  a2 -> array[1][2] = 200.0;
  a_shallow -> array[2][3] = 300.0;
  a_deep -> array[3][4] = 400.0;
  print_struct(a1, header_1);
  print_struct(a2, header_2);
  print_struct(a_shallow, header_3);
  print_struct(a_deep, header_4);
  putchar('\n');
}

/*==============================================================================*/
void print_all_array (struct Double_Array *a1, char *header_1, struct Double_Array *a2, char *header_2,  struct Double_Array *a_shallow, char *header_3 , struct Double_Array *a_deep ,char *header_4){
  print_struct(a1, header_1);
  print_struct(a2, header_2);
  print_struct(a_shallow, header_3);
  print_struct(a_deep, header_4);
}
/*==============================================================================*/
void question_2c (struct Double_Array *a1, char *header_1, struct Double_Array *a2, char *header_2,  struct Double_Array *a_shallow, char *header_3 , struct Double_Array *a_deep ,char *header_4, struct Double_Array *b1, char *header_5){

  a1 -> array[0][1] = 5000.0;
  a2 -> array[1][2] = 6000.0;
  a_shallow -> array[2][3] = 700.0;
  a_deep -> array[3][4] = 8000.0;
  b1 -> array [4][5] = 9000.0;
  print_struct(a1, header_1);
  print_struct(a2, header_2);
  print_struct(a_shallow, header_3);
  print_struct(a_deep, header_4);
  print_struct(b1, header_5);
  putchar('\n');
}
